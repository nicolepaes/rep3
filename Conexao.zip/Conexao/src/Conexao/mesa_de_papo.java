package Conexao;

public class mesa_de_papo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Pessoa p1 = new Pessoa("Jo�o:");
      Funcionario f1 = new Funcionario("Pedro:", "(44)3215467");
      Gerente g1 = new Gerente("Diana:","(67)74851258", "diana@empresa.com");
      
      System.out.println(p1.getNome() + p1.oi());
      System.out.println(f1.getNome() + f1.ola());
      System.out.println(g1.getNome() + g1.ei());
      System.out.println(f1.getNome() + f1.amigo());
      System.out.println(g1.getNome() + g1.confus());
	}
	

}
