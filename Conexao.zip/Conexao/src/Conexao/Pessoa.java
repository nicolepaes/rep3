package Conexao;

public class Pessoa {
   private String nome;
   
   public String getNome() {
	   return this.nome;
   }
   
   public Pessoa(String nome) {
	   this.nome = nome;
   }
   
   public String oi() {
	   return " Eai, beleza?";
   }
   
   
}
