package Conexao;

public class Gerente extends Funcionario{
   
   private String email;
   
   public Gerente(String nome, String tel, String email) {
	   super(nome, tel);
       this.email = email;
   }
   
   public String ei() {
	   return " Cade o relat�rio?";
   }
   
   public String confus() {
	   return super.amigo() + super.ola();
   }
}
