package Conexao;

public class Funcionario extends Pessoa {
        private String tel;
        
        
        public String getTel() {
        	return this.tel;
        }
        
        public Funcionario(String nome, String tel) {
        	super (nome);
        	this.tel = tel;
        }
        
        public String ola() {
        	return " Bom dia!";
        }
        
        public String amigo() {
        	return super.oi();
        }
}

